APK বানানোর নিয়ম (বিনামূল্যে):
1. github.com এ account খুলুন → New repository (যেকোনো নাম, Private ঠিক আছে)।
2. এই ফোল্ডারের সব ফাইল (".github" ফোল্ডারসহ) repository-তে upload করুন।
3. Actions ট্যাব → "Build APK" → চলা শেষ হলে নিচে Artifacts থেকে JLPTStudy-apk ডাউনলোড করুন (zip খুললে app-debug.apk)।
4. ফোনে APK খুলে Install করুন (Settings এ "Install unknown apps" চালু করতে হতে পারে)।
